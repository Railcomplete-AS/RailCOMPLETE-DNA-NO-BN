# xppq-cli
*XML* preprocessor with command-line interface.

For more information, see http://q37.info/tools/xppq/.

*GNU/Linux* & *OS X* : [![Travis CI](https://travis-ci.org/epeios-q37/xppq-cli.png)](https://travis-ci.org/epeios-q37/xppq-cli)
 
*Windows* : [![AppVeyor](http://ci.appveyor.com/api/projects/status/github/epeios-q37/xppq-cli)](http://ci.appveyor.com/project/epeios-q37/xppq-cli)

